package de.stefan1200.jts3servermod;

/**
 * Throw this exception, if something is wrong with the bot or plugin configuration!<br><br>
 * 
 * The author of the JTS3ServerMod is not responsible for any damage or data loss!<br><br>
 * 
 * <b>E-Mail:</b><br><a href="mailto:info@stefan1200.de">info@stefan1200.de</a><br><br>
 * <b>Homepage:</b><br><a href="http://www.stefan1200.de" target="_blank">http://www.stefan1200.de</a>
 * @author Stefan Martens
 *
 */
public class BotConfigurationException extends Exception
{
	public BotConfigurationException(String description)
	{
		super(description);
	}
}
